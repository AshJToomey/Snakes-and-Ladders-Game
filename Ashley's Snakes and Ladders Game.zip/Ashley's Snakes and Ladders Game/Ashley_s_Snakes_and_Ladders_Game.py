# Ashley's Snakes and Ladders Game (Fixed & Improved)

import turtle
import random

# Game configuration constants
BOARD_SIZE = 5
WIN_POSITION = 25
PLAYER_IMAGES = {"cow": "cow.gif", "bull": "bull.gif"}
DICE_IMAGES = [f"dice{i}.gif" for i in range(1, 7)]
SNAKES = {8: 2, 20: 0, 24: 13}
LADDERS = {5: 14, 9: 11, 18: 22}

# Initialize turtles
players = {}
player_positions = {"cow": 0, "bull": 0}
dice = turtle.Turtle()
maindraw = turtle.Turtle()
win_display = turtle.Turtle()

position_display = turtle.Turtle()
position_display.penup()
position_display.hideturtle()

def show_positions():
    """
    Display current positions of players on screen.
    """
    position_display.clear()
    cow_pos = player_positions["cow"]
    bull_pos = player_positions["bull"]
    position_display.goto(-240, 260)
    position_display.write(
        f"Cow: {cow_pos}     Bull: {bull_pos}",
        font=("Arial", 14, "bold")
    )

def register_images():
    for img in [
        "bull.gif", "cow.gif", "dice1.gif", "dice2.gif", "dice3.gif",
        "dice4.gif", "dice5.gif", "dice6.gif",
        "ladder.gif", "ladder2.gif", "ladder3.gif",
        "snake.gif", "snake2.gif", "snake3.gif",
        "win.gif"
    ]:
        turtle.register_shape(img)
        
def setup_turtles():
    """
    Initialize player turtles and display turtles.
    """
    for name, image in PLAYER_IMAGES.items():
        t = turtle.Turtle()
        t.shape(image)
        t.penup()
        players[name] = t
    dice.penup()
    win_display.penup()
    win_display.hideturtle()

def draw_board():
    """
    Draw the game board and 5x5 grid.
    """
    maindraw.speed(0)
    maindraw.width(2)
    maindraw.penup()
    maindraw.goto(-250, 250)
    maindraw.pendown()
    for _ in range(4):
        maindraw.forward(500)
        maindraw.right(90)

    # Vertical lines
    for i in range(BOARD_SIZE + 1):
        maindraw.penup()
        maindraw.goto(-250 + i * 100, 250)
        maindraw.pendown()
        maindraw.goto(-250 + i * 100, -250)

    # Horizontal lines
    for j in range(BOARD_SIZE + 1):
        maindraw.penup()
        maindraw.goto(-250, 250 - j * 100)
        maindraw.pendown()
        maindraw.goto(250, 250 - j * 100)

board_icons = []  # GLOBAL list to keep snake/ladder image turtles alive

def draw_snakes_and_ladders():
    """
    Place and persist snake and ladder image turtles on the board.
    """
    img_map = {
        8: "snake.gif",
        20: "snake2.gif",
        24: "snake3.gif",
        5: "ladder.gif",
        9: "ladder2.gif",
        18: "ladder3.gif"
    }
    for pos, img in img_map.items():
        t = turtle.Turtle()
        t.penup()
        t.hideturtle()
        t.shape(img)
        t.goto(get_coordinates(pos))
        t.showturtle()
        board_icons.append(t)  # Store in global list to prevent disappearance

def get_coordinates(position):
    """
    Convert board position to turtle coordinates.
    """
    row = (position - 1) // BOARD_SIZE
    col = (position - 1) % BOARD_SIZE
    if row % 2 == 1:
        col = BOARD_SIZE - 1 - col
    x = -250 + col * 100 + 50
    y = 250 - row * 100 - 50
    return x, y

def position_players():
    """
    Position players outside the board initially.
    """
    players["cow"].goto(-200, -180)
    players["bull"].goto(-230, -220)

def roll_dice():
    """
    Simulate rolling a dice and show the image.
    """
    result = random.randint(1, 6)
    dice.shape(DICE_IMAGES[result - 1])
    dice.goto(-300, 150)
    return result

def move_player(player_name, steps):
    """
    Move the player, handle snakes/ladders, return final position.
    """
    current_position = player_positions[player_name]
    target = min(current_position + steps, WIN_POSITION)

    if target in SNAKES:
        print(f"Oh no! {player_name.capitalize()} hit a snake!")
        target = SNAKES[target]
    elif target in LADDERS:
        print(f"Yay! {player_name.capitalize()} climbed a ladder!")
        target = LADDERS[target]

    player_positions[player_name] = target
    players[player_name].goto(get_coordinates(target))
    return target

def check_winner(position, player_name):
    """
    Display winning message and end game.
    """
    if position == WIN_POSITION:
        win_display.goto(0, 0)
        win_display.shape("win.gif")
        win_display.showturtle()
        print(f"{player_name.capitalize()} wins the game!")
        input("Press Enter to close the game.")
        turtle.bye()

def game_turn(player_name):
    """
    One turn for the player.
    """
    input(f"{player_name.capitalize()}'s turn. Press Enter to roll the dice.")
    steps = roll_dice()
    new_position = move_player(player_name, steps)
    check_winner(new_position, player_name)
    show_positions()


def main():
    turtle.setup(width=600, height=600)
    turtle.bgcolor("white")
    turtle.title("Ashley's Snakes and Ladders Game")

    register_images()
    setup_turtles()            # Initialize player turtles and dice
    draw_board()               # Draw the game board
    draw_snakes_and_ladders()  # Draw snake and ladder icons
    position_players()         # Position players off board initially

    # Game loop
    while True:
        game_turn("cow")
        game_turn("bull")

# Run the game
main()

